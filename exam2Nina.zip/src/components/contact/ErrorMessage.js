import React from "react";

function ErrorMessage({ children }) {
  return <div className="errorMessage">{children}</div>;
}

export default ErrorMessage;
