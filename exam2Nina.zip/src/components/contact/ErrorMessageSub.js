import React from "react";

function ErrorMessageSub({ children }) {
  return <div className="errorMessageSub">{children}</div>;
}

export default ErrorMessageSub;
