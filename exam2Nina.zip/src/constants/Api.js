const KEY = "5ebd138bb9da07086daa38c6";
export const BASE_URL =
  "https://us-central1-noroff-final-exam.cloudfunctions.net/api/v1/";
export const headers = {
  "Content-Type": "application/json",
  key: KEY,
};
export const PATCH = "PATCH";
export const DELETE = "DELETE";
